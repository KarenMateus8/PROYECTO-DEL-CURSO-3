# Proyecto-del-Curso-3---PW
El siguiente repositorio almacena el código requerido para la entrega del proyecto del curso 3, relacionado con la creación de una API-REST, presentado por Karen Dayana Mateus Gomez_2212765 / Carlos Eduardo Pardo Pinilla_2210075

Link Video: 
